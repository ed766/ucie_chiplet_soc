Mono-domain OpenLane2 config placeholder mirrored from the base SoC template.

