Chiplet OpenLane2 config targeting the UCIe chiplet top-level wrapper and adapter hierarchy.
This config mirrors `chiplet_extension/openlane/chiplet/` and includes `soc_chiplet_top.sdc` plus a relaxed `CLOCK_PERIOD` (200 ns) for exploratory runs.
