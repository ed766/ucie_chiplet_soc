# UCIe Chiplet SoC Project

This repository stages a two-die extension of the original three-domain RISC-V SoC. The original project lives under `base_soc/` and remains untouched so you can continue to run its regressions and flows. The new work appears under `chiplet_extension/` and adds a behavioral UCIe 2.0-style link, die partitioning, AES-backed crypto services, and automation scaffolding for simulation and physical exploration.

```
ucie_chiplet_soc/
├── base_soc/              # Exact copy of RISCV_Project (rtl/sim/upf/scripts)
├── chiplet_extension/     # New RTL, benches, scripts, and OpenLane config
│   ├── rtl/               # Die-A/B, adapters, PHY/channel, top wrappers
│   ├── sim/               # SystemVerilog benches, assertion macros
│   ├── upf/               # Power-intent placeholders for the two-die system
│   ├── reports/           # CSV outputs produced by the automation hooks
│   ├── scripts/           # Python helpers for log parsing and report merging
│   ├── Makefile           # Targets for simulation + reporting
│   └── openlane/          # LibreLane/OpenLane configuration stub
└── docs/                  # Placeholder for diagrams and waveform captures
```

## Architecture at a Glance

- **Die A (Compute chiplet)**
  - Generates 64‑bit plaintext words via `die_a_system.sv`.
  - Packetizes data into 256‑bit FLITs (`flit_packetizer.sv`), tracks credits, and drives the UCIe adapter (`ucie_tx.sv` / `ucie_rx.sv`).
  - Includes a mirrored `aes128_iterative.sv` engine to produce the expected ciphertext for scoreboard checks.

- **Die B (Crypto chiplet)**
  - Accepts FLITs from the link, depacketizes them, and aggregates two 64‑bit words into 128‑bit AES blocks.
  - Runs a full iterative AES-128 encryption (`die_b/aes128_iterative.sv`) and streams the ciphertext back toward Die A over the return path.

- **UCIe Behavioral Link**
  - `d2d_adapter/` contains flow control, CRC, retry, and link management logic mirroring the UCIe device adapter features.
  - `phy_model/phy_behavioral.sv` and `channel_model/channel_model.sv` add pipeline latency, jitter, crosstalk-induced skew, and stochastic error injection.
  - `soc_chiplet_top.sv` ties the dice together with direct signal wiring and exposes monitors for plaintext and ciphertext streams. (The `ucie_lane_if.sv` interface definition is available if you choose to reintroduce it.)

- **Power Intent**
  - UPF templates (`upf/die_a.upf`, `upf/die_b.upf`, `upf/pst_chiplet.upf`) define four domains (`AON_A`, `PD1_RV32`, `AON_B`, `PD2_AES`) and a cross-die power-state table (RUN, SLEEP, CRYPTO_ONLY, DEEP_SLEEP). These files mirror the structure of the base SoC but require elaboration before sign-off.

## Simulation Flow

The new Makefile under `chiplet_extension/` provides two main goals:

```bash
cd chiplet_extension
make chiplet-sim          # Emits stub logs (default SIM_TOOL=stub)
make chiplet-report       # Rebuilds CSV metrics under reports/
```

Set `SIM_TOOL=iverilog` to compile and run the SystemVerilog testbenches with Icarus Verilog once it is installed:

```bash
make chiplet-sim SIM_TOOL=iverilog
```

The benches (`tb_ucie_prbs.sv` and `tb_soc_chiplets.sv`) exercise the link and the full two-die datapath, respectively. They depend on a simulator with complete SystemVerilog support. Verilator can be used as an alternative but currently requires additional refactoring (queue replacements and SV function tweaks) to execute the benches without further warnings.

## Physical-Design Exploration

`chiplet_extension/openlane/chiplet/config.json` is a LibreLane/OpenLane2 configuration stub targeting `soc_chiplet_top`. Invoke LibreLane from the cloned `librelane/` repository in the workspace:

```bash
cd ~/librelane
python3 -m librelane \
  --pdk-root ~/.ciel/ciel/sky130/versions/<your_sky130_rev> \
  ~/ucie_chiplet_soc/chiplet_extension/openlane/chiplet/config.json
```

LibreLane runs already exist under `chiplet_extension/openlane/chiplet/runs/` in this workspace. If you are running in a fresh environment, install LibreLane dependencies (`cloup`, etc.) or use the documented Nix/Docker setup. OpenLane/OpenROAD does not support SystemVerilog `interface` constructs, so if you reintroduce `ucie_lane_if.sv` into the top-level wiring, flatten it before hardening.
  
### Quick LibreLane Run (Local PDK Example)

If you have the Ciel-managed Sky130 PDK installed locally, you can point LibreLane at it directly:

```bash
cd ~/librelane
python3 -m librelane \
  --pdk-root ~/.ciel/ciel/sky130/versions/0fe599b2afb6708d281543108caf8310912f54af \
  ~/ucie_chiplet_soc/chiplet_extension/openlane/chiplet/config.json
```

Notes:
- If your LibreLane setup uses Volare, you can replace `--pdk-root` with `--pdk sky130A`.
- The alternate config at `~/ucie_chiplet_soc/openlane/chiplet/config.json` is equivalent; it points at the same RTL.

## Current Status & Outstanding Work

- LibreLane runs complete end-to-end in this workspace with a relaxed clock target (e.g., 200 ns) and produce final layout outputs, so the flow is operational.
- RTL has been refactored to remove obvious placeholders (XOR crypto, hard-coded CRC stubs) and to use a proper AES-128 core, but the flow is still functional/behavioral—no sign-off verification has been performed.
- Testbenches compile conceptually; running them requires a simulator with full SV feature support. Install Icarus Verilog or adjust the RTL for Verilator’s SV subset before relying on automated runs.
- UPF files are skeletal. Additional supply sets, isolation, retention, and power-switch definitions are needed to integrate with UPF-aware toolchains.
- The reporting scripts continue to emit placeholder metrics until real simulation logs are produced.
- Timing closure is not representative yet; tighter clocks still show significant setup violations, and slow-corner max slew/max cap warnings remain.


This README will continue to evolve as the automation and verification environments mature. Contributions and fixes—especially around simulator compatibility—are welcome.
